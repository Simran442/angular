import { Component, OnInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})

export class AboutUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function(){
    $("#scorll1").click(function () {
      $('html,body').animate({
          scrollTop: $(".main-est-sec").offset().top
        },
        '3000');

    });

    $("#scorll2").click(function () {
      $('html,body').animate({
          scrollTop: $(".founder-sec").offset().top
        },
        '3000');

    });

    $("#scorll3").click(function () {
      $('html,body').animate({
          scrollTop: $(".doctor-sec").offset().top
        },
        '3000');

    });

  });
  window.scrollTo(0, 0)
}
}