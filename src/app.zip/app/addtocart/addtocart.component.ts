import { Component, OnInit } from '@angular/core';
import Client from 'shopify-buy';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
export class AddtocartComponent implements OnInit {
  checkout: any;
  constructor(private route: Router,private spinner:Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.listproduct()
  }


  listproduct() {
    this.spinner.show();
    var shopClient = Client.buildClient({
      storefrontAccessToken: '10e55cf8f17988e1fb3a81ade7f5c085',
      domain: '@innerbeautyco.myshopify.com',
    });

  /*   shopClient.checkout.create().then((checkout) => {
      // Do something with the checkout
      console.log("checkoutttttttt0", checkout);
    });
 */

    const checkoutId = 'Z2lkOi8vc2hvcGlmeS9DaGVja291dC85ZjkzY2Q5Y2U3ZDI2ZjQwYjQwNzE3MTg0MjcwNzdhMD9rZXk9MWQ1MGU4YWRmNjA4ZDQ4ZWQ5MjQzNDNhNTMzYzM4MzM=';

    shopClient.checkout.fetch(checkoutId).then((checkout) => {
      this.spinner.hide();
      this.checkout = checkout;
      console.log('checkout here', this.checkout)
    });
  }


  checkoutId() {
    console.log("hello checkout")
    this.route.navigate(['/checkout']);
  }


  UpdateItem() {

    var shopClient = Client.buildClient({
      storefrontAccessToken: '10e55cf8f17988e1fb3a81ade7f5c085',
      domain: '@innerbeautyco.myshopify.com',
    });

    const checkoutId = 'Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0SW1hZ2UvMTgyMTc3ODc1OTI='; // ID of an existing checkout
    const lineItemsToUpdate = [
      {id: 'Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0Lzc4NTc5ODkzODQ=', quantity: 2}
    ];
    
    // Update the line item on the checkout (change the quantity or variant)
    shopClient.checkout.updateLineItems(checkoutId, lineItemsToUpdate).then((checkout) => {
      // Do something with the updated checkout
      console.log(checkout.lineItems); // Quantity of line item 'Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0Lzc4NTc5ODkzODQ=' updated to 2
    });
  }

  removeItem(id) {
  
    var shopClient = Client.buildClient({
      storefrontAccessToken: '10e55cf8f17988e1fb3a81ade7f5c085',
      domain: '@innerbeautyco.myshopify.com',
    });

    const checkoutId = 'Z2lkOi8vc2hvcGlmeS9DaGVja291dC85ZjkzY2Q5Y2U3ZDI2ZjQwYjQwNzE3MTg0MjcwNzdhMD9rZXk9MWQ1MGU4YWRmNjA4ZDQ4ZWQ5MjQzNDNhNTMzYzM4MzM='; // ID of an existing checkout
    // ID of an existing checkout
    const lineItemIdsToRemove = [
      id
    ];

    // Remove an item from the checkout
    shopClient.checkout.removeLineItems(checkoutId, lineItemIdsToRemove).then((checkout) => {
      this.route.navigate(["/checkout"]); 
 
    });
  }
}
