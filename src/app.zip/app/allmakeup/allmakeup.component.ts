import { HomeService } from './../services/home.service';
import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import ShopifyBuy from 'shopify-buy';
declare var $: any;

@Component({
  selector: 'app-allmakeup',
  templateUrl: './allmakeup.component.html',
  styleUrls: ['./allmakeup.component.css']
})
export class AllmakeupComponent implements OnInit {

  [x: string]: any;

  public api_url: any;
  products: any;

  constructor(public http: Http, private HomeService: HomeService, private route: Router, private spinner: Ng4LoadingSpinnerService) {

  }


  ngOnInit() {
    this.task();
    this.allcategory();
  }

  task() {
    this.spinner.show();
    this.HomeService.plans().subscribe((response) => {

      this.products = response.users.products
      this.spinner.hide();
    });


  }

  allcategory() {
    this.spinner.show();
    this.HomeService.allcategory().subscribe((response) => {

      this.category = response.custom_collections;
      this.spinner.hide();

    });
  }


  addtocart(id, quantity) {
    this.encodeID = btoa(id);

    var shopClient = ShopifyBuy.buildClient({
      storefrontAccessToken: '5b8486079b1f1777db3fbd173af1baa9',
      domain: '@miaawwws.myshopify.com',
    });

    const checkoutId = 'Z2lkOi8vc2hvcGlmeS9DaGVja291dC9mN2U4OWM1MmMyYmRiOGJlYjBlN2NlYzhhZDMxMTdjMz9rZXk9ODhlMmMwMzYwZTk4OWYxZDVkOGIwNTM1YTlhNGY3NmE='; // ID of an existing checkout

    var lineItemsToAdd = [
      { variantId: this.encodeID, quantity: 2 }
    ];

    shopClient.checkout.addLineItems(checkoutId, lineItemsToAdd).then((checkout) => {

      // Do something with the updated checkout
      this.route.navigate(['/cart']);

    });
  }

  popup(id) {
    $("#popup").modal('show');
    this.HomeService.productId(id).subscribe((response) => {
      this.reviewProduct = response.users;

      this.reviewimages = this.reviewProduct.id;

    });

  }

}
