import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FlashMessagesService } from 'angular2-flash-messages';
import { ActivatedRoute } from '@angular/router';

declare var $: any;


@Component({
  selector: 'app-articalblog',
  templateUrl: './articalblog.component.html',
  styleUrls: ['./articalblog.component.css']
})
export class ArticalblogComponent implements OnInit {
  public article:any;
  sub:any;
  id:any;
  hide:any;
  itemsid:any;

  constructor(public http: Http, private HomeService: HomeService, private route: Router, private spinner: Ng4LoadingSpinnerService,private _flashMessagesService: FlashMessagesService,private activatedRoute: ActivatedRoute) {

  }

  ngOnInit() {

    this.sub = this.activatedRoute.params.subscribe(params => {
      this.id = + params['id'];
      this.itemsid = +params['id']; // (+) converts string 'id' to a number
      this.hide = false;

      this.articleBlog(this.id,this.itemsid);
      this.blog()
    });
    window.scrollTo(0, 0)
 
  }

  articleBlog(id, itemid){
    this.HomeService.articleBlog(id, itemid).subscribe((response) => {
      this.article = response.users.articles;
     console.log('blog=>>', this.article)
    });
  }

  blog(){
    this.HomeService.Blogs().subscribe((response) => {
      this.article = response.users.articles;
     
    });
  }

}
