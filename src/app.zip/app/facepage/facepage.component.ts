import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { Ng4LoadingSpinnerService  } from 'ng4-loading-spinner';
declare var $: any;


@Component({
  selector: 'app-facepage',
  templateUrl: './facepage.component.html',
  styleUrls: ['./facepage.component.css']
})
export class FacepageComponent implements OnInit {

  public api_url: any;
  products: any;
  subs: any;
  id: any;
  hide: any;
  category:any;
  reviewProduct:any;
  reviewimages:any;
  count:number = 0;

  constructor(public http: Http, private HomeService: HomeService, private route: Router, private activatedRoute: ActivatedRoute, private spinner: Ng4LoadingSpinnerService) {

  }


  ngOnInit() {
    this.subs = this.activatedRoute.params.subscribe(params => {
      this.id = + params['id']; // (+) converts string 'id' to a number
      this.hide = false;
      this.newproducts(this.id);
      this.allcategory();
    });
   
  }


  newproducts(id) {
       this.spinner.show(); 
      this.HomeService.LipsID(id).subscribe((response) => {
        
        this.products = response.users.products;
        this.spinner.hide(); 
      });
    }


  allcategory(){
    this.spinner.show();
    this.HomeService.allcategory().subscribe((response) => {
     
      this.category = response.custom_collections;
      this.spinner.hide();
  
      });
  }


  

  onclick(id){
    this.HomeService.productId(id).subscribe((response) => {
   
      this.products = response.users;
      console.log('newwwwwwwwwwwdataaa=>>>', typeof(this.products))
   });

    $("#myModal").modal('show');
  }


  popup(id){
    $("#popup").modal('show');
    this.HomeService.productId(id).subscribe((response) => {
      this.reviewProduct = response.users;

      this.reviewimages = this.reviewProduct.id; 
     
   });
  
  }

  add(){
    this.count++;
  }

  sub(){
    this.count--;  
  }

}
