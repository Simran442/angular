import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { HomeService } from './../services/home.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { AlertsService } from '@jaspero/ng-alerts';
declare var $: any;
import Client from 'shopify-buy';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  registerForm: FormGroup;
  loading = false;
  submitted = false;
  checkout: any;
  public addtoCartCount: any;
  public addtocart: any;

  constructor(public http: Http, private HomeService: HomeService, private _alert: AlertsService, private route: Router, private formBuilder: FormBuilder
  ) {

  }

  ngOnInit() {

    this.registerForm = this.formBuilder.group({

      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]

    });
    if (localStorage.getItem("store_owner_ad_contacts") == null) {
      $("#myModal").modal('show');
    }

  }

  Login() {
    $("#login").modal('show');

  }


  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }



    this.HomeService.login(this.registerForm.value.email, this.registerForm.value.password)
      .pipe(first())
      .subscribe(
        data => {
          console.log(data.user);
          /*  let loginUser;
     
           loginUser =  data.email; */

          localStorage.setItem('loginUser', data.user);

          $("#login").modal('hide');
        },
        error => {

          let message;
          error = JSON.parse(error._body);
          message = error.message;
          const type = 'error';
          console.log(message);
          this._alert.create(type, message);


        });


  }

  aadtocart() {
    this.route.navigate(['/cart']);
    
    
    var shopClient = Client.buildClient({
      storefrontAccessToken: '5b8486079b1f1777db3fbd173af1baa9',
      domain: '@miaawwws.myshopify.com',
    });

    const checkoutId ='Z2lkOi8vc2hvcGlmeS9DaGVja291dC9mN2U4OWM1MmMyYmRiOGJlYjBlN2NlYzhhZDMxMTdjMz9rZXk9ODhlMmMwMzYwZTk4OWYxZDVkOGIwNTM1YTlhNGY3NmE=';

    shopClient.checkout.fetch(checkoutId).then((checkout) => {
      // Do something with the checkout
      console.log('totalcheckout', checkout);
      this.checkout = checkout;
    });
    /*  $.get('https://miaawwws.myshopify.com/cart.js',function(response){
       console.log(response);
     });  */
    /*   this.HomeService.addtocartss().subscribe((response)=>{
        console.log('response=>', response);
      }) */
    /* $("#imagesBag").modal('show');
     this.HomeService.addtocartGet().subscribe((response) => {
      this.addtocart =  response.addcart;
      
      this.addtoCartCount = response.addcart.length;
  
      });  */


    /*    client.checkout.fetch(this.checkout).then((checkout) => {
       // Do something with the checkout
       console.log('total  checkout', checkout);
     }); */

  }

}
