import { HomeService } from './../services/home.service';
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
declare var $: any;


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  [x: string]: any;


  registerForm: FormGroup;
  loading = false;
  submitted = false;


  public api_url: any;
  event: any;
  date: any;
  constructor(public http: Http, private HomeService: HomeService, private route: Router, private formBuilder: FormBuilder
  ) {

  }


  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
     /*  password: ['', [Validators.required]] */
    });
    window.scrollTo(0, 0)

    this.task();
    this.comboPack();
  }

  task() {
    $("#myModal").modal('show');
    this.event = new Date();

    this.events = this.event.toISOString();

    this.date = new Date(this.event);
    /* year = this.date.getFullYear();
   */
    this.dt = this.date.getDate();
    this.year = this.date.getFullYear();
    this.month = this.date.getMonth() + 1;
    if (this.dt < 10) {
      this.dt = '0' + this.dt;
    }
    if (this.month < 10) {
      this.month = '0' + this.month;
    }
    this.format = this.year + '/' + this.month + '/' + this.dt;

    this.HomeService.newLineup().subscribe((response) => {

      for (this.dataa in response.users.products) {
        this.newdate = response.users.products[this.dataa].created_at;
        this.subdates = new Date(this.newdate);
        this.dts = this.subdates.getDate();

        this.newyear = this.subdates.getFullYear();
        this.newmonth = this.subdates.getMonth() + 1;
        if (this.dts < 10) {
          this.dts = '0' + this.dt;
        }
        if (this.newmonth < 10) {
          this.newmonth = '0' + this.month;
        }
        this.newformat = this.newyear + '/' + this.newmonth + '/' + this.dts;

        this.date1 = new Date(this.format);
        this.date2 = new Date(this.newformat);
        this.timeDiff = Math.abs(this.date2.getTime() - this.date1.getTime());
        this.diffDays = Math.ceil(this.timeDiff / (1000 * 3600 * 24));
        if (this.differDays > 90) {
          this.products = response.users.products
        } else {
          this.products = response.users.products

        }

      }


    });
  }

  comboPack() {
    this.HomeService.comboPack().subscribe((response) => {

      this.pack = response.users.products;

    })

  }

  /*   onClickMe(id) {
      $("#myModal").modal('hide');
      this.HomeService.LipsID(id).subscribe((response) => {
  
        this.products = response.Lipresult;
     
      });
    } */

  get f() { return this.registerForm.controls; }

  onSubmit() {
 
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }

    console.log('my email=>', this.registerForm.value.email);

        $("#myModal").modal('hide');
    
        $("#Thanku").modal('show');
    
    
        this.HomeService.register(this.registerForm.value.email)
          .pipe(first())
          .subscribe(
            data => {
    
            },
            error => {
    
              let message;
              error = JSON.parse(error._body);
              message = error.message;
              const type = 'error';
              console.log(message)
    
            });
  }


  onLogin() {

    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }

    console.log('my email=>', this.registerForm.value);

        /* mutation customerAccessTokenCreate(this.registerForm.value: CustomerAccessTokenCreateInput!) {
          customerAccessTokenCreate(input: this.registerForm.value) {
            customerAccessToken {
              accessToken
              expiresAt
            }
            customerUserErrors {
              code
              field
              message
            }
          }
        } */


  }


  popup(id) {
    $("#popup").modal('show');
    this.HomeService.productId(id).subscribe((response) => {
      this.reviewProduct = response.users;

      this.reviewimages = this.reviewProduct.id;

    });

  }

  aadtocart() {
    console.log("done")

    this.route.navigate(['/cart']);
    /*    /*   $.get('https://miaawwws.myshopify.com/cart.js',function(response){
           console.log(response);
         });  */
    /* this.HomeService.addtocartss().subscribe((response)=>{
      console.log('response=>', response);
    }) */


  }

  add(){
    $(document).ready(function(){
      // This button will increment the value
      $('.plus').click(function(e){
          // Stop acting like a button
          e.preventDefault();
          // Get the field name
          this.fieldName = $(this).attr('field');
          // Get its current value
          var currentVal = parseInt($('input[name='+this.fieldName+']').val());
          // If is not undefined
          if (!isNaN(currentVal)) {
            console.log('currentval=>', currentVal + 1)
              // Increment
              $('input[name='+this.fieldName+']').val(currentVal + 1);
          } else {
              // Otherwise put a 0 there
              $('input[name='+this.fieldName+']').val(0);
          }
      });
      // This button will decrement the value till 0
      $(".minus").click(function(e) {
          // Stop acting like a button
          e.preventDefault();
          // Get the field name
          this.fieldName = $(this).attr('field');
          // Get its current value
          var currentVal = parseInt($('input[name='+this.fieldName+']').val());
          // If it isn't undefined or its greater than 0
          if (!isNaN(currentVal) && currentVal > 0) {
              // Decrement one
              console.log(currentVal - 1)
              $('input[name='+this.fieldName+']').val(currentVal - 1);
          } else {
              // Otherwise put a 0 there
              $('input[name='+this.fieldName+']').val(0);
          }
      });
  });

  }
}
