
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FlashMessagesService } from 'angular2-flash-messages';
declare var $: any;


@Component({
  selector: 'app-makeup',
  templateUrl: './makeup.component.html',
  styleUrls: ['./makeup.component.css']
})
export class MakeupComponent implements OnInit {
  public lipsProduct:any;
  eyeProducts:any;
  faceProducts:any;

  constructor(public http: Http, private HomeService: HomeService, private route: Router, private spinner: Ng4LoadingSpinnerService,private _flashMessagesService: FlashMessagesService) {

  }

  ngOnInit() {
    this.featured_Lip();
   /*  this.featured_eye();
    this.featured_face(); */
  }


  featured_Lip(){
    this.HomeService.featured_Lip().subscribe((response) => {
      this.lipsProduct = response.users.products;
      console.log("featuredProducts", this.lipsProduct)
    });
  }

/*   featured_eye(){
    this.HomeService.featured_eye().subscribe((response) => {
      this.eyeProducts = response.users.products
    });
  }

  featured_face(){
    this.HomeService.featured_face().subscribe((response) => {
      this.faceProducts = response.users.products
    });
  } */
}
