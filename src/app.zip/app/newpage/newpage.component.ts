
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FlashMessagesService } from 'angular2-flash-messages';
declare var $: any;
import ShopifyBuy from 'shopify-buy';

@Component({
  selector: 'app-newpage',
  templateUrl: './newpage.component.html',
  styleUrls: ['./newpage.component.css']
})
export class NewpageComponent implements OnInit {

  public api_url: any;
  products: any;
  reviewProduct :any;
  reviewimages:string;
  category:any;
  encodeID:any;
  collection = [];
  count:number = 0;
  constructor(public http: Http, private HomeService: HomeService, private route: Router, private spinner: Ng4LoadingSpinnerService,private _flashMessagesService: FlashMessagesService) {
    for (let i = 1; i <= 100; i++) {
      this.collection.push(`item ${i}`);
    }

  }

  ngOnInit() {
    this.newproducts();
    this.allcategory();
  }

  newproducts() {
    this.spinner.show();
    this.HomeService.plans().subscribe((response) => {
      this.products = response.users.products;
     this.spinner.hide();
      //this.products = response.users.products
      

    });
  }

  allcategory(){
    this.HomeService.allcategory().subscribe((response) => {
    this.category = response.custom_collections;
    });
  }

  onClick(id) {
    this.HomeService.LipsID(id).subscribe((response) => {
      this.products = response.users.products;
    });
  }


  popup(id){
    
    $("#popup").modal('show');
    this.HomeService.productId(id).subscribe((response) => {
      this.reviewProduct = response.users;

      this.reviewimages = this.reviewProduct.id; 
     
   });
  
  }
  addtocart(id, quantity) {
    this.encodeID = btoa(id);
  
    var shopClient = ShopifyBuy.buildClient({
            storefrontAccessToken: '5b8486079b1f1777db3fbd173af1baa9',
            domain: '@miaawwws.myshopify.com',
      });

      const checkoutId = 'Z2lkOi8vc2hvcGlmeS9DaGVja291dC9mN2U4OWM1MmMyYmRiOGJlYjBlN2NlYzhhZDMxMTdjMz9rZXk9ODhlMmMwMzYwZTk4OWYxZDVkOGIwNTM1YTlhNGY3NmE='; // ID of an existing checkout

        var lineItemsToAdd = [
          {variantId: this.encodeID , quantity: 2}
        ];

        shopClient.checkout.addLineItems(checkoutId, lineItemsToAdd).then((checkout) => {
        
          this.route.navigate(['/cart']);
       
        });
  }

  pagination(quantity){
    console.log(quantity)
  }

  add(){
    this.count++;
    console.log(this.count)
  }
  sub(){
    this.count--;
    console.log(this.count)
  }

}
