import { Router } from '@angular/router';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';
import ShopifyBuy from 'shopify-buy';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
declare var $: any;
declare var window: any;

@Component({
  selector: 'app-onclick',
  templateUrl: './onclick.component.html',
  styleUrls: ['./onclick.component.css']
})
export class OnclickComponent implements OnInit {
  @ViewChild('myId') myId: ElementRef;

  public api_url: any;
  ratingSize: any;
  products: any;
  showSlides: any;

  ratingReview: any;
  sub: any;
  id: any;
  hide: any;
  shade: string;
  quantity: any;
  addtoCartCount: any;
  checkout: any;
  lineItemsToAdd: any;
  checkoutArray: any;
  encodeID: any;
  clientid:any;
  checkoutsID:any;
  constructor(public http: Http, private HomeService: HomeService, private route: Router, private activatedRoute: ActivatedRoute, private _flashMessagesService: FlashMessagesService,private spinner:Ng4LoadingSpinnerService) {

  }

  ngOnInit() {
    $(document).ready(function(){
      // This button will increment the value
      $('.plus').click(function(e){
          // Stop acting like a button
          e.preventDefault();
          // Get the field name
          this.fieldName = $(this).attr('field');
          // Get its current value
          var currentVal = parseInt($('input[name='+this.fieldName+']').val());
          // If is not undefined
          if (!isNaN(currentVal)) {
              // Increment
              $('input[name='+this.fieldName+']').val(currentVal + 1);
          } else {
              // Otherwise put a 0 there
              $('input[name='+this.fieldName+']').val(0);
          }
      });
      // This button will decrement the value till 0
      $(".minus").click(function(e) {
          // Stop acting like a button
          e.preventDefault();
          // Get the field name
          this.fieldName = $(this).attr('field');
          // Get its current value
          var currentVal = parseInt($('input[name='+this.fieldName+']').val());
          // If it isn't undefined or its greater than 0
          if (!isNaN(currentVal) && currentVal > 0) {
              // Decrement one
              $('input[name='+this.fieldName+']').val(currentVal - 1);
          } else {
              // Otherwise put a 0 there
              $('input[name='+this.fieldName+']').val(0);
          }
      });
  });
  

    this.sub = this.activatedRoute.params.subscribe(params => {
 
      this.id = + params['id']; // (+) converts string 'id' to a number
      this.hide = false;

      this.productsID(this.id);
 
      this.reviewRating();
    });
    window.scrollTo(0, 0)
  }

  productsID(id) {
    this.HomeService.productId(id).subscribe((response) => {
      this.products =  response.users.product;
    });
  }

  reviewRating() {
    this.HomeService.reviewrating().subscribe((response) => {
      this.ratingSize = response.review.length
      this.ratingReview = response.review;
    })
  }



  addtocart(id, quantity) {
    this.quantity = parseInt(quantity);
    console.log('myquantity', typeof(parseInt(quantity)))
    this.spinner.show();
    this.encodeID = btoa(id);
    console.log('encode', this.encodeID)
  
 /*    var shopClient = ShopifyBuy.buildClient({
            storefrontAccessToken: '5b8486079b1f1777db3fbd173af1baa9',
            domain: '@miaawwws.myshopify.com',
      }); */

      var shopClient = ShopifyBuy.buildClient({
        storefrontAccessToken: '10e55cf8f17988e1fb3a81ade7f5c085',
        domain: '@innerbeautyco.myshopify.com',
  });
  // window.shop = shopClient;

  /* shopClient.checkout.create().then((checkout) => {
    // Do something with the checkout
    console.log('mycheckout here', checkout);
  }); */

      const checkoutId = 'Z2lkOi8vc2hvcGlmeS9DaGVja291dC85ZjkzY2Q5Y2U3ZDI2ZjQwYjQwNzE3MTg0MjcwNzdhMD9rZXk9MWQ1MGU4YWRmNjA4ZDQ4ZWQ5MjQzNDNhNTMzYzM4MzM='; // ID of an existing checkout

        var lineItemsToAdd = [
          {variantId: this.encodeID , quantity: this.quantity}
        ];

      //console.log('hellloooo', lineItemsToAdd)

        shopClient.checkout.addLineItems(checkoutId, lineItemsToAdd).then((checkout) => {
          this.spinner.hide();
          console.log('checkoutthereme', checkout)
          // Do something with the updated checkout
        this.route.navigate(['/cart']);
       
        });
  }

  add(){
    $('.plus').click(function(e){
      // Stop acting like a button
      e.preventDefault();
      // Get the field name
      this.fieldName = $(this).attr('field');
      // Get its current value
      var currentVal = parseInt($('input[name='+this.fieldName+']').val());
      // If is not undefined
      if (!isNaN(currentVal)) {
          // Increment
          $('input[name='+this.fieldName+']').val(currentVal + 1);
      } else {
          // Otherwise put a 0 there
          $('input[name='+this.fieldName+']').val(0);
      }
  });
  
  }

  subs(){
    $(".minus").click(function(e) {
      // Stop acting like a button
      e.preventDefault();
      // Get the field name
      this.fieldName = $(this).attr('field');
      // Get its current value
      var currentVal = parseInt($('input[name='+this.fieldName+']').val());
      // If it isn't undefined or its greater than 0
      if (!isNaN(currentVal) && currentVal > 0) {
          // Decrement one
          $('input[name='+this.fieldName+']').val(currentVal - 1);
      } else {
          // Otherwise put a 0 there
          $('input[name='+this.fieldName+']').val(0);
      }
  });
}
 /*  add(){
  $(".minus").on("click", function() {


    var $button = $(this),
      $input = $button.closest('.quantity buttons_added').find("input.mydata");
    var oldValue = $input.val(),
      newVal;
  
    if ($.trim($button.text()) == "+") {
  
      newVal = parseFloat(oldValue) + 1;
    } else {
      // Don't allow decrementing below zero
      if (oldValue > 0) {
        newVal = parseFloat(oldValue) - 1;
      } else {
        newVal = 0;
      }
    }
  
    $input.val(newVal);
  });
}
 */
}