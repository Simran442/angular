import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Router , ActivatedRoute} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HomeService } from '../services/home.service';

import { first } from 'rxjs/operators';

interface ICompany {
    id: number;
    rating: number;
    contact: string;
    company: string;
  }


@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

    sub:any;
    id:any;
    hide:any;
    productid:number;
    @Input() rating: number;
    @Input() itemId: number;
    //@Output() ratingClick: EventEmitter<any> = new EventEmitter<any>();
    inputName: string;
    products: any;
    ratingClicked: number;
    itemIdRatingClicked: string;


  registerForm: FormGroup;
    loading = false;
    submitted = false;


    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private HomeService: HomeService
        /* private userService: UserService,
        private alertService: AlertService) */ ){ }

    ngOnInit() {
      this.sub = this.activatedRoute.params.subscribe(params => {
        this.id = + params['id']; // (+) converts string 'id' to a number
       this.hide = false;
       this.productid = this.id;
     });
      this.productsID(this.id);

        this.inputName = '_rating';
        this.registerForm = this.formBuilder.group({
          productid:this.productid,
          review_handline: ['', Validators.required],
          comments: ['', Validators.required],
          nickname: ['', Validators.required],
          location: ['', Validators.required],
          email: ['', Validators.required],
          rating: ['',Validators.required],

            /*password: ['', [Validators.required, Validators.minLength(6)]] */
        });
        
        
        
    }

    productsID(id){
      this.HomeService.productId(id).subscribe((response) => {
   
        this.products = response.users;
        console.log('newproducts', this.products)
     });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        this.loading = true;
        console.log('valuee', this.registerForm.value)
        
        this.HomeService.review(this.registerForm.value)
            .pipe(first())
            .subscribe(
                data => {
                    
                    this.router.navigate(['/']);
                },
                error => {
                
                    this.loading = false;
                });
    }


    onClick(rating: number): any {
        console.log("rating", rating)
        console.log('hello', rating)
      
        this.rating = rating;
       /*  this.ratingClick.emit({
          rating: rating
        }); */
      }
}
