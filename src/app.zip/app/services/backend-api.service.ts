import { Injectable,Component } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class BackendApiService {

  public api_url: any;
  public backend_url: any;
/*   constructor() {
    this.api_url = 'http://localhost:3000/api/v1/';
    this.backend_url = 'http://localhost:3000/';
  } */
   constructor() {
    this.api_url = 'https://shoping1-backend.herokuapp.com/api/v1/';
    this.backend_url = 'https://shoping1-backend.herokuapp.com';
   }
   
}
