
import { BackendApiService } from './backend-api.service';
import { Injectable, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
//import 'rxjs/add/operator/catch';
//import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


import { HttpHeaders, HttpClient } from '@angular/common/http';
const httpOptions = {
    headers: new Headers({ 'Content-Type': 'application/json' })
};
 
@Injectable({
  providedIn: 'root'
})

export class HomeService {

    public api_url: any;

    constructor(public http: Http, private global: BackendApiService) {
      this.api_url = this.global.api_url;
    }

    plans() {
        return this.http.get(this.api_url.concat('listData'), {}).pipe(
        map((res: Response) => res.json()));
       
    }

    skincareProduct(){
        return this.http.get(this.api_url.concat('SkincareProducts'),{}).pipe(
        map((res: Response) => res.json()));   
    }

    Skincarecontent(){
        return this.http.get(this.api_url.concat('SkincareContent'),{}).pipe(
            map((res: Response) => res.json()));  
    }
    
    newLineup() {
        return this.http.get(this.api_url.concat('newOurLineUp'), {}).pipe(
        map((res: Response) => res.json()));
       
    }

    comboPack() {
        return this.http.get(this.api_url.concat('combopack'), {}).pipe(
        map((res: Response) => res.json()));
       
    }

    Lips(){
        return this.http.get(this.api_url.concat('LipsProducts'),{}).pipe(
            map((res : Response)=>res.json())
        );
    }


    LipsID(id){
        return this.http.get(this.api_url.concat('LipsProducts/'+ id),{}).pipe(
            map((res : Response)=>res.json())
        );
    }


    subcategories(id){
        return this.http.get(this.api_url.concat('Subcategory/'+id),{}).pipe(
            map((res: Response)=>res.json())
        )
    }



   allcategory(){
    return this.http.get(this.api_url.concat('Allcategory'),{}).pipe(
        map((res: Response)=>res.json())
    )
    
   }
    productId(id){
        return this.http.get(this.api_url.concat('onclick/'+ id),{}).pipe(
            map((res: Response)=>res.json())
        )
    }

    review(user) {
       
        return this.http.post(this.api_url.concat('review'),{
            user:user
        }).pipe(
            map((res: Response)=>res.json())
        )
    }

    reviewrating() {
        return this.http.get(this.api_url.concat('review'),{}).pipe(
            map((res: Response)=>res.json())
        )
    }

   
    register(email) {
     

        return this.http.post(this.api_url.concat('register'), {
          email: email
          
        }).pipe(
            map((res: Response)=>res.json())
        )
    
      }
    
      login(email,password){


        return this.http.post(this.api_url.concat('login'), {
            email: email,password: password
          }).pipe(
              map((res: Response)=>res.json())
          )
      
      }
  

      addtocart(title,price ,id,img,quantity,shades){
          return this.http.post(this.api_url.concat('addToCart'),{
              title: title,price: price, id:id,img:img,quantity:quantity,shades:shades
          }).pipe(
              map((res: Response)=>res.json())
          )

      }

      addtocartGet(){
        return this.http.get(this.api_url.concat('addToCart'),{}).pipe(
            map((res: Response)=>res.json())
        )
    }


    featured_Lip(){
        return this.http.get(this.api_url.concat('Featured_Lip_Products'),{}).pipe(
            map((res: Response)=>res.json())
        )
    }
    featured_eye(){
        return this.http.get(this.api_url.concat('Featured_Lip_Products'),{}).pipe(
            map((res: Response)=>res.json())
        )
    }
    featured_face(){
        return this.http.get(this.api_url.concat('Featured_Lip_Products'),{}).pipe(
            map((res: Response)=>res.json())
        )
    }



    addtocartss(){

        return this.http.get('https://miaawwws.myshopify.com/cart.js',{}).pipe(
            map((res: Response)=> res.json())
        )

    }


    articleBlog(id,item){
        return this.http.get(this.api_url.concat('articleBlog/id/item'),{}).pipe(
            map((res: Response)=>res.json())
        )

    }
    
    Blogs(){
        return this.http.get(this.api_url.concat('blog'),{}).pipe(
            map((res: Response)=>res.json())
        )

    }
}
