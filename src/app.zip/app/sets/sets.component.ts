import { Component, OnInit } from '@angular/core';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
declare var $: any;

@Component({
  selector: 'app-sets',
  templateUrl: './sets.component.html',
  styleUrls: ['./sets.component.css']
})
export class SetsComponent implements OnInit {
  products: any;

 /*  customOptions: any = {
    loop: true,
    autoplay:true,
    navSpeed: 700,
    dots: true,
    navText: ['', ''],
    responsive: {
      0: {
      items: 2,
      nav: true
      },
      600: {
      items: 3,
      nav: false
      },
      1000: {
      items: 3,
      nav: true,
      loop: false,
      margin: 20
      }
    },
    nav: true
  } */
  customOptions: any = {
  loop:true,
  margin:10,
  responsiveClass:true,
  autoplay:true,
  responsive:{
      0:{
          items:2,
          nav:true
      },
      600:{
          items:3,
          nav:true
      },
      1000:{
          items:3,
          nav:true,
          loop:true
      },
      1200:{
         items:3,
         nav:true,
         loop:true
      }


  }
}
   constructor(public http: Http, private HomeService: HomeService, private route: Router, private spinner: Ng4LoadingSpinnerService) {

  }

  ngOnInit() {
    
    this.task();   
      $(".owl-carousel").owlCarousel();
   
  }
  task() {
    this.spinner.show();
    this.HomeService.plans().subscribe((response) => {
      
      this.products = response.users.products
      this.spinner.hide();
    });
  }

}
