import { Component, OnInit } from '@angular/core';
import { HomeService } from './../services/home.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
declare var $: any;

@Component({
  selector: 'app-skincare',
  templateUrl: './skincare.component.html',
  styleUrls: ['./skincare.component.css']
})
export class SkincareComponent implements OnInit {

  

  [x: string]: any;

  public api_url: any;
  products: any;
  content:any;
  count:number = 0;

  customOptions: any = {
    loop: true,
    autoplay:true,
    navSpeed: 700,
    dots: true,
    navText: ['', ''],
    responsive: {
      0: {
      items: 2,
      nav: true
      },
      600: {
      items: 3,
      nav: false
      },
      1000: {
      items: 3,
      nav: true,
      loop: false,
      margin: 20
      }
    },
    nav: true
  }
  constructor(public http: Http, private HomeService: HomeService, private route: Router, private spinner: Ng4LoadingSpinnerService) {

  }


  ngOnInit() {
    
    this.skincare();
    /* this.SkincareContent(); */
    /* $(".owl-carousel").owlCarousel(); */
    $("owl-carousel").owlCarousel({
      navText:["<div class='nav-btn prev-slide'></div>","<div class='nav-btn next-slide'></div>"],
    })
   /*  $( ".owl-prev").html('<i class="fa fa-chevron-left"></i>');
     $( ".owl-next").html('<i class="fa fa-chevron-right"></i>'); */
  }

  skincare() {
    this.spinner.show();
    this.HomeService.skincareProduct().subscribe((response) => {
      
      this.products = response.users.products
      this.spinner.hide();
    });
  }

  SkincareContent(){
    this.HomeService.Skincarecontent().subscribe((response) => {
      
      this.content = response.users.collection;
     console.log('sdfjksfsdfsdf', response.users)
    });

  }
/*   featured_Lip(){
    this.HomeService.featured_Lip().subscribe((response) => {
      this.lipsProduct = response.users.products;
      console.log("featuredProducts", this.lipsProduct)
    });
  } */

  popup(id) {
    
    $("#popup").modal('show');
    this.HomeService.productId(id).subscribe((response) => {
      this.reviewProduct = response.users;

      this.reviewimages = this.reviewProduct.id;

    });

  }

  onclick(id) {
    this.HomeService.productId(id).subscribe((response) => {

      this.products = response.users;
    });

    $("#myModal").modal('show');
  }


  add(){
    this.count++;
  }
  sub(){
    this.count--;  
  }
}
