/* $(document).ready(function() {
  $('.set-product').owlCarousel({
	loop: true,
	margin:5,
	responsiveClass: true,
	autoplay:true,
    autoplayTimeout:5000,
	responsive: {
	  0: {
		items: 2,
		nav: true
	  },
	  600: {
		items: 2,
		nav: false
	  },
	  1000: {
		items: 6,
		nav: true,
		loop: false,
		margin: 20
	  }
	}
  })
})
				
$(document).ready(function() {
  $('.abcd').owlCarousel({
	loop: true,
	margin:5,
	responsiveClass: true,
	autoplay:true,
    autoplayTimeout:5000,
	responsive: {
	  0: {
		items: 2,
		nav: true
	  },
	  600: {
		items: 2,
		nav: false
	  },
	  1000: {
		items: 3,
		nav: true,
		loop: false,
		margin: 20
	  }
	}
  })
}) */